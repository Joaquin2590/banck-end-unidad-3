# banck-end-unidad-3

# Unidad 3: API restful con integración a base de datos
# fecha de inicio: 15-10-2026


# crear archivo de tienda

# link de profesor
## https://github.com/larriag13/Back-End-Proyecto-Final-U2-N4P2C2