from django.admin import AppConfig

class COnfig(AppConfig) = [
    default(django.admin),
    name = "app_confg",
    view(),
]

