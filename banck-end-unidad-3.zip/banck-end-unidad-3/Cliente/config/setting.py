import os

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [os.path.join(BASE_DIR, 'templates')],  # Directorio global de templates
        'APP_DIRS': True,  # Habilita la búsqueda de templates dentro de las apps
        'OPTIONS': {
            'context_processors': [
                # Context processors por defecto
                'django.template.context_processors.request',
                'django.template.context_processors.static',  # Para archivos estáticos
            ],
        },
    },
]
1-"variable_llamado_perdido"


import django mensaje

2-"stactit run"
Stactic = "/Stactic/" 
[
    "envia en la lista producto"
]



3- "class sociedad" 